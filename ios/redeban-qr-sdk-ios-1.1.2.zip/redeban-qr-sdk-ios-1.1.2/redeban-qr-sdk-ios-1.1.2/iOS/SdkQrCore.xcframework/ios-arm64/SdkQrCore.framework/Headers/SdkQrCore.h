//
//  SdkQrCore.h
//  SdkQrCore
//
//  Created by Yenderson Sanchez on 6/05/25.
//

#import <Foundation/Foundation.h>

//! Project version number for SdkQrCore.
FOUNDATION_EXPORT double SdkQrCoreVersionNumber;

//! Project version string for SdkQrCore.
FOUNDATION_EXPORT const unsigned char SdkQrCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SdkQrCore/PublicHeader.h>


